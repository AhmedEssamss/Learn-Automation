import { test, expect } from '@playwright/test';

test.beforeAll (async ({page}) => {
    console.log("Before All Tests");
});

test.afterAll (async ({page}) => {
    console.log("After All Tests");
});

test.beforeEach (async ({page}) => {
    await page.goto("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
    console.log("Before Each Test");
});
test.afterEach (async ({page}) => {
    console.log("After Each Test");
});



test.describe('Login page', () => {

    test('valid login', async ({ page }) => {
        await page.locator("input[placeholder='Username']").fill("Admin");
        await page.locator("input[placeholder='Password']").fill("admin123");
        await page.locator("button[type='submit']").click();
        await expect(page.locator("//h6[normalize-space()='Dashboard']")).toBeVisible();
    });

     test('invalid login', async ({ page }) => {
        await page.locator("input[placeholder='Username']").fill("Admin");
        await page.locator("input[placeholder='Password']").fill("admin12");
        await page.locator("button[type='submit']").click();
        await expect(page.locator("//p[@class='oxd-text oxd-text--p oxd-alert-content-text']")).toBeVisible();
    });

});